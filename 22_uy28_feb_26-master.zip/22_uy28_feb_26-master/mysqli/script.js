var hello= 'hello';

function dhaka() {
  console.log(hello);
}

dhaka();
console.log(hello);